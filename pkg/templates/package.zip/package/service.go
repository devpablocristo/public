package sdkservice

import (
	"sync"

	"github.com/devpablocristo/sdk/pkg/templates/package/defs"
)

var (
	instance  defs.Service
	once      sync.Once
	initError error
)

type service struct {
	config defs.Config
}

func newService(c defs.Config) (defs.Service, error) {
	once.Do(func() {
		// initError example
		// s, err := initService(config)
		// if err != nil {
		// 	initError = fmt.Errorf("error: %w", err)
		// 	return
		// }

		instance = &service{
			config: c,
		}
	})
	return instance, initError
}
