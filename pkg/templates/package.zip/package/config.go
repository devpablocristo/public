package sdkservice

import "github.com/devpablocristo/sdk/pkg/templates/package/defs"

type config struct {
	dbName string
	envVar string
}

func newConfig(dbName, envVar string) defs.Config {
	return &config{
		dbName: dbName,
		envVar: envVar,
	}
}

func (c *config) Validate() error {
	return nil
}
