package sdkservice

import (
	"github.com/devpablocristo/sdk/pkg/templates/package/defs"
	"github.com/spf13/viper"
)

func Bootstrap(dbName string) (defs.Service, error) {
	config := newConfig(
		dbName,
		viper.GetString("ENV_VAR_NAME"),
	)

	if err := config.Validate(); err != nil {
		return nil, err
	}

	return newService(config)
}
