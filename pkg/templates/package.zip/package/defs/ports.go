package defs

type Config interface {
	Validate() error
}

type Service interface{}
