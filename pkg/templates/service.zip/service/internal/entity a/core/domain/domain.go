package domain

type User struct {
	UUID  string
	Name  string
	Email string
}
