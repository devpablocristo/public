package projectname

type useCases struct{}

func NewUseCases() {}
