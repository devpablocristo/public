package transport

import (
	"github.com/devpablocristo/sdk/pkg/templates/service/internal/core/domain"
)

type UserDataModel struct {
	UUID  string `bd:"uuid"`
	Name  string `bd:"name"`
	Email string `bd:"email"`
}

func ToUserDomain(user UserDataModel) *domain.User {
	return &domain.User{
		UUID:  user.UUID,
		Name:  user.Name,
		Email: user.Email,
	}
}

func ToUserDataModel(user *domain.User) UserDataModel {
	return UserDataModel{
		UUID:  user.UUID,
		Name:  user.Name,
		Email: user.Email,
	}
}
