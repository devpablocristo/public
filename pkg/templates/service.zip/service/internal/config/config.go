package config

import (
	"log"

	"github.com/spf13/viper"

	sdkclo "github.com/devpablocristo/sdk/pkg/config/config-loader"
)

var (
	AfipToken   string
	AfipSecret  string
	MiArgSecret string
)

func init() {
	if err := sdkclo.LoadConfig("config/.env", "config/.env.local"); err != nil {
		log.Fatalf("Viper Service error: %v", err)
	}
}

func Load() {
	AfipToken = viper.GetString("AFIP_TOKEN_ENDPOINT")
	if AfipToken == "" {
		log.Fatal("AFIP_TOKEN_ENDPOINT is required")
	}

	AfipSecret = viper.GetString("AFIP_CLIENT_SECRET")
	if AfipSecret == "" {
		log.Fatal("AFIP_CLIENT_SECRET is required")
	}

	MiArgSecret = viper.GetString("MIARG_CLIENT_SECRET")
	if MiArgSecret == "" {
		log.Fatal("MIARG_CLIENT_SECRET is required")
	}
}
